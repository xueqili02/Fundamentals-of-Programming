/*
	Program: Task_5
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-20
	Description: get the string and sort it. Ask user to input and implement add, delete, quit and save operation
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#define MAX 5

int getHolidays(char* filename, char holidayList[][100])
{
	FILE* fp;
	fp = fopen(filename,"r");
	if(fp==NULL)
	{
		fp = fopen(filename,"w");
	}
	char a;
	int i=0,j=0,size;
	a=fgetc(fp);
	while( a!=EOF )
	{
		if(a=='\n')
		{
			holidayList[i][j]='\0';
			i++;j=0;
		}
		else
		{
			holidayList[i][j]=a;
			j++;size++;
		}
		a=fgetc(fp);
	}
	if(a==EOF)holidayList[i][j]='\0';
	fclose(fp);
	printf("The original list is:\n");
	for(int i=0;i<MAX;i++)
	{
		printf("%s\n",holidayList[i]);
	}
	return size;
}

void swap(char (*a)[100],char (*b)[100])
{
	char temp[1000];
	strcpy(temp,*a);
	strcpy(*a,*b);
	strcpy(*b,temp);
}

void sortList(char (*holidayList) [100], int listLength)
{
		for(int i=0;i<listLength;i++)
		{
			for(int j=0;j<listLength-i-1;j++)
			{
				if(strcmp(*(holidayList+j),*(holidayList+1+j))>0)
				{
					char temp[100];
					strcpy(temp,*(holidayList+j));
					strcpy(*(holidayList+j),*(holidayList+j+1));
					strcpy(*(holidayList+j+1),temp);
				}
			}
		}
}
int main()
{
	FILE* fp;
	char holidayList[MAX+100][100],holiday_add[100];
	int size,choice,holiday_num=0,row,choice_num=1;
	size=getHolidays("Holidays.txt",holidayList);
	printf("\nThe size of Holiday list is: %d\n",size);
	sortList(holidayList,MAX);
	printf("\nThe sorted list is:\n");
	for(int i=0;i<MAX;i++)
	{
		printf("%s\n",holidayList[i]);
	}
	printf("\nuser-choice list:\n(1)add\n(2)delete\n(3)quit\n");
	while(scanf("%d",&choice))
	{
		if(choice==1)
		{
			choice_num++;
			printf("Please input the holiday you want to add: ");
			fflush(stdin);
			gets(holidayList[MAX+holiday_num]);holiday_num++;
			sortList(holidayList,MAX+holiday_num);
			for(int i=0;i<MAX+holiday_num;i++)
			{
				printf("%s\n",holidayList[i]);
			}
		}
		if(choice==2)
		{
			choice_num++;
			printf("Please input the row you want to delete: ");
			fflush(stdin);
			scanf("%d",&row);
			for(int i=row;i<MAX+holiday_num-1;i++)
			{
				strcpy( *(holidayList+i),*(holidayList+i+1) );
			}
			holiday_num--;
			for(int i=0;i<MAX+holiday_num;i++)
			{
				printf("%s\n",holidayList[i]);
			}
		}
		if(choice==3&&choice_num!=1)
		{
			fflush(stdin);
			printf("Do you want to save the change(y/n): ");
			char save=getchar();
			save = tolower(save);
			if(save == 'y')
			{
				FILE* fp;
				fp = fopen("Holidays.txt","w");
				if(fp==NULL)
				{
					printf("File cannot be found.\n");
					return 0;
				}
				for(int i=0;i<MAX+holiday_num;i++)
				{
					fputs(holidayList[i],fp);
					fputc('\n',fp);
				}
				fclose(fp);
				return 0;
			}
			else if(save == 'n')
			{
				return 0;
			}
		}
		else if(choice==3&&choice_num==1)return 0;
	}
	return 0;
}