/*
	Program: Task_4
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-19
	Description: based on command line argument to implement transform the string to lowercase,uppercase, and reverse
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

void up(char *str)
{
	int length=strlen(str);
	for(int i=0;i<length;i++)
	{
		str[i] = toupper(str[i]);
	}
}

void low(char *str)
{
	int length=strlen(str);
	for(int i=0;i<length;i++)
	{
		str[i] = tolower(str[i]);
	}
}

int main(int argc, char *argv[])
{
	char str[1000],a[3]="-u",b[3]="-l",c[3]="-r";
	FILE* fp;
	fp = fopen("message.txt","r");
	if(fp==NULL)
	{
		printf("File cannot be found.");
		exit(1);
	}
	if(argc==1)
	{
		while(fgets(str,1000,fp)!=NULL)
		{
			printf("%s",str);
		}
		printf("\n");
		return 0;
	}
	else if(argc!=2)
	{
		printf("Usage: filename, -u/-l/-r\n");
		exit(1);
	}
	if(strcmp(argv[1],a)==0)
	{
		while(fgets(str,1000,fp)!=NULL)
		{
			up(str);
			printf("%s",str);
		}
	}
	else if(strcmp(argv[1],b)==0)
	{
		while(fgets(str,1000,fp)!=NULL)
		{
			low(str);
			printf("%s",str);
		}
	}
	else if(strcmp(argv[1],c)==0)//reverse output
	{
		while(fgets(str,1000,fp)!=NULL)
		{
			int len_str=strlen(str),m=0;
			char temp[1000];
			for(int i=len_str-1;i>=0;i--)
			{
				if(str[i]==' ')
				{
					for(int j=m-1;j>=0;j--)
					{
						if(temp[j]!='\n')printf("%c",temp[j]);
					}
					printf(" ");
					m=0;
				}
				else
				{
					temp[m]=str[i];
					m++;
					if(i==0)
					{
						for(int j=m-1;j>=0;j--)printf("%c",temp[j]);
					}
				}
			}
			printf("\n");
		}
	}
	fclose(fp);
	return 0;
}
