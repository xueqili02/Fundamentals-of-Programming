/*
	Program: Task_1
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-18
	Description: implement the game"TIC-TAC-TOE"
*/
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

void displayArray(char array[])
{
	printf("TIC-TAC-TOE\n");
	for(int i=0;i<9;i++)
	{
		if(i%3==0 && i!=0)printf("\n");
		printf("%c ",array[i]);
	}
}
//judge if the player wins
int score(const char array[])
{
	int X=1,O=2,T=3;
	bool flag=true;
	if(    ((array[0]==array[1])&&(array[1]==array[2])&&array[0]=='X') || ((array[3]==array[4])&&(array[4]==array[5])&&array[3]=='X') || ((array[6]==array[7])&&(array[7]==array[8])&&array[6]=='X') 
		|| ((array[0]==array[4])&&(array[4]==array[8])&&array[0]=='X') || ((array[2]==array[4])&&(array[4]==array[6])&&array[2]=='X') 
		|| ((array[0]==array[3])&&(array[3]==array[6])&&array[0]=='X') || ((array[1]==array[4])&&(array[4]==array[7])&&array[1]=='X') || ((array[2]==array[5])&&(array[5]==array[8])&&array[2]=='X') )
	{
		return X;
	}
	else if(    ((array[0]==array[1])&&(array[1]==array[2])&&array[0]=='O') || ((array[3]==array[4])&&(array[4]==array[5])&&array[3]=='O') || ((array[6]==array[7])&&(array[7]==array[8])&&array[6]=='O') 
			 || ((array[0]==array[4])&&(array[4]==array[8])&&array[0]=='O') || ((array[2]==array[4])&&(array[4]==array[6])&&array[2]=='O') 
			 || ((array[0]==array[3])&&(array[3]==array[6])&&array[0]=='O') || ((array[1]==array[4])&&(array[4]==array[7])&&array[1]=='O') || ((array[2]==array[5])&&(array[5]==array[8])&&array[2]=='O') )
	{
		return O;
	}
	for(int i=0;i<9;i++)
	{
		if(array[i]>'0'&&array[i]<='9')
		{
			flag=false;break;
		}
	}
	if(flag)return T;
	else return 4;
}

void play(char XorO, char array[])
{
	displayArray(array);
	printf("\nPlayer %c, please enter the number in the display(1~9)\nwhere you wish your mark to be placed.\n", XorO);
	int pos;
	bool flag=false;
	scanf("%d",&pos);
	while(!flag)
	{
		if(array[pos-1]>'9')
		{
			printf("Illegal move. Place %d is occupied.\nPlease take another move.\n",pos);
			scanf("%d",&pos);
		}
		if(array[pos-1]>'0' && array[pos-1]<='9')flag=true;
	}	
	array[pos-1] = XorO;
	system("cls");
}

void playGame(char array[])
{
	int num=0;
	while(num<9)
	{
		num++;
		if(num%2==1)play('X', array);
		else play('O', array);

		if(score(array)==1)
			{displayArray(array);printf("\nPlayer X wins.\n");break;}
		if(score(array)==2)
			{displayArray(array);printf("\nPlayer O wins.\n");break;}
		if(score(array)==3)printf("\nThis is a tie. No winner.\n");
		if(score(array)==4)continue;
	}
}

int main()
{
	char array[10];
	for(int i=0;i<10;i++)
	{
		array[i] = (char) ('1'+i);
	}
	array[9]='\0';
	playGame(array);
	return 0;
}