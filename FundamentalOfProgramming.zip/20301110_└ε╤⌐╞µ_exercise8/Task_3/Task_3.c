/*
	Program: Task_3
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-18
	Description: get an 4 by 5 array and calculate the average and display it, find its max number 
*/
#include<stdio.h>
#include<stdlib.h>

void getNum(double num[][5])
{
	FILE *fp;
	fp = fopen("data.txt","r");	
	if(fp==NULL)
	{
		printf("File cannot be found.\n");
		exit(1);
	}
	double a;
	fscanf(fp,"%lf",&a);
	
	for(int i=0;i<4;i++)
		for(int j=0;j<5;j++)
		{
			if(a==EOF)break;
			num[i][j]=a;
			fscanf(fp,"%lf",&a);
		}
	fclose(fp);
}
//calculate and display average of each set
void calcAvg_display(double num[][5])
{
	double avg,sum;
	for(int i=0;i<4;i++)
	{
		sum=0;
		for(int j=0;j<5;j++)
		{
			sum+=num[i][j];
		}
		avg=sum/5;
		printf("The average value of set %d is: %lf\n",i,avg);
	}
}
//calculate the average of all numbers
double calcAvg_all(double (*num)[5])
{
	double avg,sum=0;
	for(int i=0;i<4;i++)
		for(int j=0;j<5;j++)
		{
			sum+=num[i][j];
		}
	avg = sum/20;
	return avg;
}

double findMax(double (*num)[5])
{
	double max=num[0][0];
	for(int i=0;i<4;i++)
		for(int j=0;j<5;j++)
		{
			if(num[i][j]>max)max=num[i][j];
		}
	return max;
}

int main()
{
	double num[4][5],avg,max;
	getNum(num);
	for(int i=0;i<4;i++)
		for(int j=0;j<5;j++)
		{
			printf("%lf ",num[i][j]);
		}
	printf("\n");
	calcAvg_display(num);
	avg=calcAvg_all(num);
	printf("The average value of all numbers is: %lf\n",avg);
	max=findMax(num);
	printf("The max is:%lf\n",max);
	return 0;
}