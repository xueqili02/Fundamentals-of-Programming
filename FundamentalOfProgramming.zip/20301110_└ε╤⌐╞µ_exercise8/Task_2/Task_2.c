/*
	Program: Task_2
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-18
	Description: display separately of numbers that are divisible by 3 and are not divisible by 3
*/
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
//check if reach the end of file
bool check(char a)
{
	if(a==EOF)return false;
	else return true;
}

int main()
{
	FILE* fr;
	FILE* fw1;
	FILE* fw2;
	fr = fopen("num.txt","r");
	fw1 = fopen("write1.txt","w");
	fw2 = fopen("write2.txt","w");
	if(fr==NULL || fw1==NULL || fw2==NULL)
	{
		printf("File cannot be found.\n");
		exit(1);
	}
	char num;
	num=fgetc(fr);
	while(check(num))
	{
		if(num=='0' || num=='3' || num=='6' || num=='9')fputc(num,fw1);//check if it is divisible by 3
		else fputc(num,fw2);
		num=fgetc(fr);
	}
	fclose(fr);
	fclose(fw1);
	fclose(fw2);
	return 0;
}