#include<stdio.h>

int main(void)
{
	printf("��ѩ�� 20301110 Where there is a will, there is a way.\n"); 
	
	return 0;
}
