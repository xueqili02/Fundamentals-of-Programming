#include<stdio.h>

int main()
{ 
	int hourlysalary1 = 18, hourlysalary2 = 10;
	int grosspay1, grosspay2;
	float netpay1, netpay2;
	
	grosspay1 = hourlysalary1 * 35;
	grosspay2 = hourlysalary2 * 40;
	netpay1 = grosspay1 * (1-0.22);
	netpay2 = grosspay2 * (1-0.22);
	
	printf("%d %.2f\n", grosspay1, netpay1);
	printf("%d %.2f", grosspay2, netpay2);
	
	return 0;
}

