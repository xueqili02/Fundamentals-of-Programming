/*
	Program: Task_4
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-12-02
	Description: reverse a linked list between the head node and the given node
*/
#include<stdio.h>
#include<stdlib.h>

typedef struct node
{
	int value;
	struct node *next;
} ListNode;

ListNode *reverseKGroup(ListNode *head, int k)
{
	
	ListNode *temp=head,*first=head,*after;
	for(;;)
	{
		temp=temp->next;
		if(temp->value==k)
		{
			after=temp->next;//k后一个
			break;
		}
		if(temp->next==NULL)return head;
	}
	ListNode *begin=temp,*mid=head,*end=head->next;
	for(;;)
	{
		mid->next=begin;
		if(end==temp)break;
		begin=mid;
		mid=end;
		end=end->next;
	}
	
	end->next=mid;
	head->next=after;
	return end;
}

int main()
{
	ListNode *head=(ListNode*)malloc(sizeof(ListNode));
	int k,n;
	
	ListNode* num=head;
	printf("Please input five numbers to construct the linked list.\n");
	for(int i=1;i<=5;i++)
	{
		scanf("%d",&n);
		ListNode* temp=(ListNode*)malloc(sizeof(ListNode));
		if(temp==NULL)
		{
			printf("Allocation failed.\n");
			exit(1);
		}
		temp->next=NULL;
		num->value=n;

		num->next=temp;
		num=num->next;
	}
	printf("Please input an integer: ");
	scanf("%d",&k);
	head=reverseKGroup(head,k);

	ListNode* temp;
	temp=head;
	while(temp->next!=NULL)
	{
		printf("%d ",temp->value);
		temp=temp->next;
	}
	free(temp);
	return 0;
}