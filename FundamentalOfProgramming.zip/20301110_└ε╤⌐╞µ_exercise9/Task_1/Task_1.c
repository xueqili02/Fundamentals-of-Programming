/*
	Program: Task_1
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-25
	Description: calculate the days between two dates and display it
*/
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

typedef struct
{
	int month;
	int day;
	int year;
} MyDate;

bool isLeapYear(int year)
{
	return ( (year%4==0&&year%100!=0)||(year%400==0) );
}

int difDays(MyDate *d1, MyDate *d2)
{
	int days, d1_days=0, d2_days=0;
	if(d1->year==d2->year)
	{
		if(d1->month==d2->month)
		{
			days=abs(d1->day-d2->day);
			return days;
		}
	}
	for(int i=1;i<d1->month;i++)
	{
		switch(i)
		{
			case 1: d1_days+=31;break;
			case 2: if(isLeapYear(d1->year)){d1_days+=29;break;}
					else {d1_days+=28;break;}
			case 3: d1_days+=31;break;
			case 4: d1_days+=30;break;
			case 5: d1_days+=31;break;
			case 6: d1_days+=30;break;
			case 7: d1_days+=31;break;
			case 8: d1_days+=31;break;
			case 9: d1_days+=30;break;
			case 10: d1_days+=31;break;
			case 11: d1_days+=30;break;
		}
	}
	d1_days+=d1->day;
	for(int i=1;i<d2->month;i++)
	{
		switch(i)
		{
			case 1: d2_days+=31;break;
			case 2: if(isLeapYear(d2->year)){d2_days+=29;break;}
					else {d2_days+=28;break;}
			case 3: d2_days+=31;break;
			case 4: d2_days+=30;break;
			case 5: d2_days+=31;break;
			case 6: d2_days+=30;break;
			case 7: d2_days+=31;break;
			case 8: d2_days+=31;break;
			case 9: d2_days+=30;break;
			case 10: d2_days+=31;break;
			case 11: d2_days+=30;break;
		}
	}
	d2_days+=d2->day;
	if(d1->year < d2->year)
	{
		for(int i=d1->year;i<d2->year;i++)
		{
			if(isLeapYear(i))d2_days+=366;
			else d2_days+=365;
		}
	}
	else
	{
		for(int i=d2->year;i<d1->year;i++)
		{
			if(isLeapYear(i))d1_days+=366;
			else d1_days+=365;
		}
	}
	days = abs(d1_days-d2_days);
	return days;
}

void showDate(MyDate day)
{
	printf("%d-%02d-%02d",day.year,day.month,day.day);
}

int main()
{
	MyDate d1,d2;
	int days;
	printf("Please input two dates in the format of year, month and day.\n");
	scanf("%d%d%d",&d1.year,&d1.month,&d1.day);
	scanf("%d%d%d",&d2.year,&d2.month,&d2.day);
	days=difDays(&d1,&d2);
	printf("There are %d days between ",days);
	showDate(d1);
	printf(" and ");
	showDate(d2);
	printf("\n");
	return 0;
}