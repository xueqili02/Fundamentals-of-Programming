/*
	Program: Task_2
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-29
	Description: read car records from a file and calculate each car's miles per gallon
*/
#include<stdio.h>

typedef struct
{
	char idNumber[100];
	int mile,gallon;
} Car;

void read(Car *car)
{
	FILE* fp;
	fp = fopen("record.txt","r");
	if(fp==NULL)
	{
		printf("File cannot be found.");
	}
	fseek(fp,37L,SEEK_SET);
	for(int i=0;i<5;i++)
	{
		int a,b;
		fscanf(fp,"%s %s %d,%d %d", &car[i].idNumber[0], &car[i].idNumber[3], &a,&b,&car[i].gallon);
		car[i].mile=1000*a+b;
	}
	fclose(fp);
	
}

void report(Car car[])
{
	float MilePerGallon,sum_mile=0,sum_gallon=0;
	printf("Car Number\tMiles Per Gallon\n");
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<3;j++)printf("%c",car[i].idNumber[j]);
		printf("%s\t",&car[i].idNumber[3]);
		printf("%f\n",car[i].mile*1.0/car[i].gallon);
		sum_mile+=car[i].mile;
		sum_gallon+=car[i].gallon;
	}
	printf("All\t\t%f\n",sum_mile/sum_gallon);
}

int main()
{
	Car car[5];
	read(car);
	report(car);
	return 0;
}