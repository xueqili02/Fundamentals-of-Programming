﻿#include "dict.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
/*Global variable */

struct dictionary *dict;

int wordsNumber; //number of words

/*definitions of the functions*/

/* Read a file which contains words and their definitions into the array of structures, return the number of words.

If the file does not exist, return 0.

*/

int loadDictionary(char * fileName) {
	struct dictionary store[1000];
	dict=store;
	FILE *fp;
	fp=fopen(fileName,"r");
	if(fp==NULL)return 0;
	char judge;
	int k=0,j=0,i=0;
	bool is_word=false;
	for(;;)
	{
		judge=fgetc(fp);
		if(judge==EOF)break;
		if(judge=='\n')
		{
			i++;j=0;k=0;is_word=false;continue;
		}
		if(judge==' ')is_word=true;
		if(is_word==false)
		{
			(*(dict+i)).word[j]=judge;j++;continue;
		}	
		else if(is_word==true)
		{
			(*(dict+i)).definition[k]=judge;k++;continue;
		}
	}
	fclose(fp);
	wordsNumber=i;
	return wordsNumber;
}

/* look up the word in the dictionary, return the address of the structure if the word is found, return NULL if not found.

*/

struct dictionary * lookup(char * word) {
	bool flag=false;
	for(int i=0;i<wordsNumber;i++)
	{
		if( strcmp(word,dict[i].word) == 0 )
		{
			printf("%s %s\n",dict[i].word,dict[i].definition);
			flag=true;
			break;
		}
	}
	if(!flag)printf("the definition of the word is not found.\n");
}