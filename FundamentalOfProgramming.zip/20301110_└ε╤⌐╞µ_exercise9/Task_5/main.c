﻿/*
	Program: Task_5
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-12-4
	Description: implement a simple searchable dictionary
*/
#include "dict.h"
//#include <stdio.h>
//#include <stdlib.h>
#include <string.h>
int main() {

	/* data structure for the dictionaryassume less than 1000 words in the dictionary*/
	struct dictionary myDict[1000];

	/* File name*/
	char * fileName ="dictionary.txt";

	/* initialize the global variable*/
	struct dictionary *dict = myDict;

	/* read from file, get the dictionary*/
	wordsNumber = loadDictionary(fileName);
	printf("There are %d words in the dictionary.\n",wordsNumber);
	int choice=0;
	char word[200];
	printf("Choice 1: look up a word.\nChoice 2: quit\n");
	while(1)
	{
		printf("Please input your choice: ");
		fflush(stdin);
		scanf("%d",&choice);
		if(choice==2)break;
		else if(choice==1)
		{
			printf("Please input the word you want to look up:\n");
			fflush(stdin);
			gets(word);
			lookup(word);
		}
		else
		{
			printf("Invalid choice. Please input again!\n");
			continue;
		}
	}
	return 0;
}