/*
	Program: Task_3
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-29
	Description: implement an EMU seats reservation
*/
#include<stdio.h>
#include<stdbool.h>

typedef struct
{
	int idNumber;
	bool isReserved;
	char firstName[50],lastName[50];
}EMU;

void promptDisplay(int n)
{
	if(n==1)
	{
		printf("To choose a function, enter its label:\n");printf("1) Show the total number of empty seats.\n");
		printf("2) Show situation of all seat.\n");printf("3) Show the information of a seat.\n");
		printf("4) Reserve an empty seat to a customer.\n");printf("5) Delete a seat reservation.\n");
		printf("6) Save the current reservations.\n");printf("0) Quit.\n");
	}
	else
	{
		printf("To choose a function, enter its label:\n");printf("1) Show the total number of empty seats.\n");
		printf("2) Show situation of all seat.\n");printf("3) Show the information of a seat.\n");
		printf("4) Reserve an empty seat to a customer.\n");printf("5) Delete a seat reservation.\n");
		printf("6) Save the current reservations.\n");
	}
}

void showEmptyNumber(EMU seats[][60])
{
	int cnt=0;
	for(int i=0;i<5;i++)
		for(int j=0;j<60;j++)
		{
			if(seats[i][j].isReserved==false)cnt++;
		}
	printf("The total number of empty seats is %d.\n",cnt);
}

void showSeatSituation(EMU seats[][60])
{
	int cnt=0;
	for(int i=0;i<5;i++)
	{
		printf("*Carriage %d*",i+1);
		
		for(int j=0;j<60;j++)
		{
			if(cnt%6==0)printf("\n");
			if(seats[i][j].isReserved==true)printf("R");
			else printf("O");
			cnt++;
		}
		printf("\n");
	}
}

void showSeatInfo(EMU seats[][60])
{
	printf("If you want to abort the entry, please input 0 and 0.\n");
	int carriage,id;
	printf("Please choose which carriage and which seat you look for.\n");
	scanf("%d%d",&carriage,&id);
	if(carriage==0 && id==0)return;
	if(seats[carriage-1][id-1].isReserved==true)
	{
		printf("The first and last name of seat holder is: %s %s.\n"
			,seats[carriage-1][id-1].firstName,seats[carriage-1][id-1].lastName);
	}
	else printf("This seat is empty.\n");
}

void reserveSeat(EMU (*seats)[60])
{
	printf("If you want to abort the entry, please input 0 and 0.\n");
	int carriage,id;
	printf("Please choose which carriage and id Number of the seat you want to reserve.\n");
	while(scanf("%d%d",&carriage,&id))
	{
		if(carriage==0 && id==0)return;
		if(seats[carriage-1][id-1].isReserved==true)
		{
			printf("This seat has been reserved, please choose another seat.\n");continue;
		}
		seats[carriage-1][id-1].isReserved=true;
		printf("Please input your first name and last name.\n");
		scanf("%s%s",seats[carriage-1][id-1].firstName,seats[carriage-1][id-1].lastName);
		break;
	}
}

void deleteSeat(EMU (*seats)[60])
{
	printf("If you want to abort the entry, please input 0 and 0.\n");
	int carriage,id;
	printf("Please input the carriage and the id number of the seat you want to delete.\n");
	while(scanf("%d%d",&carriage,&id))
	{
		if(carriage==0 && id==0)return;
		if(seats[carriage-1][id-1].isReserved==false)
		{
			printf("This seat is empty, please choose another seat.\n");continue;
		}
		seats[carriage-1][id-1].isReserved=false;
		seats[carriage-1][id-1].firstName[0]='\0';
		seats[carriage-1][id-1].lastName[0]='\0';
		break;
	}
}

void saveReservation(EMU (*seats)[60])
{
	FILE* fp;
	fp = fopen("SeatReservation.dat","wb");
	fwrite(seats, sizeof(EMU), 300, fp);
	fclose(fp);
}

int main()
{
	int choice=-1;
	EMU seats[5][60];
	FILE* fp;
	fp = fopen("SeatReservation.dat", "rb");
	if(fp==NULL)
	{
		for(int i=0;i<5;i++)
		{
			int cnt=1;
			for(int j=0;j<60;j++)
			{
				seats[i][j].idNumber=cnt;
				seats[i][j].isReserved=false;// at the beginning no seat is reserved
				cnt++;
			}
		}
	}
	else
	{
		for(int i=0;i<5;i++)
			for(int j=0;j<60;j++)
			{
				fread(&seats[i][j],sizeof(EMU),1,fp);
			}
	}
	while(choice!=0)
	{
		if(choice==-1)promptDisplay(1);
		else promptDisplay(0);
		scanf("%d",&choice);
		if(choice<0 || choice>6){printf("Invalid input! Please input again!\n");continue;}
		switch(choice)
		{
			case 1: showEmptyNumber(seats);break;
			case 2: showSeatSituation(seats);break;
			case 3: showSeatInfo(seats);break;
			case 4: reserveSeat(seats);break;
			case 5: deleteSeat(seats);break;
			case 6: saveReservation(seats);break;
			case 0: saveReservation(seats);break;
			default: break;
		}
	}
	return 0;
}