/*
	Program: Task_3
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-12
	Description: reporting the number of spaces, lowercases, uppercases and other characters of an English statement.
*/
#include<stdio.h>

int main()
{
	char s;
	int spaces=0, uppercases=0, lowercases=0, others=0;//number of characters
	
	printf("Please input an English statement:");//input
	while( scanf("%c", &s) && s!='\n')
	{
		//counting numbers
		if(s==' ')spaces++;
		else if(s>='a' && s<='z')lowercases++;
		else if(s>='A' && s<='Z')uppercases++;
		else others++;
	}
	//output
	printf("Spaces: %d\nLowercases: %d\nUppercases: %d\nOthers: %d\n", 
			spaces, lowercases, uppercases, others);
	return 0;
}
