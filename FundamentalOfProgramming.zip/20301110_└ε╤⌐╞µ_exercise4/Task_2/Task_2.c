/*
	Program: Task_2
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-12
	Description: output the days of a month based on year and month user inputted
*/
#include<stdio.h>

int main()
{
	int year, month, day;
	//input
	printf("Enter a year:");
	scanf("%d", &year);
	printf("Enter a month (use a 1 for Jan., 2 for Feb., etc.):");
	scanf("%d", &month);
	if(month<1 || month>12)
	{
		printf("You have inputted an invalid month!");return 0;//juding if the input is valid
	}
	
	//judge and ouput
	if(month==4 || month==6 || month==9 || month==11)
	{
		day = 30;
		printf("%d\n", day);
	}
	else if(month!=2)
	{
		day = 31;
		printf("%d\n", day);
	}
	else
	{
		if(( year%4==0 && year%100!=0 ) || ( year%400==0 ))
		{
			day = 29;
			printf("%d\n", day);
		}
		else
		{
			day = 28;
			printf("%d\n", day);
		}
	}
	return 0;
}
