/*
	Program: Task_Bonus
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-12
	Description: judging what day of the week the user's input is
*/
#include<stdio.h>

int isleap(int n)
{
	if(( n%4==0 && n%100!=0 ) || ( n%400==0 ))return 1;
	return 0;
}

int main()
{
	int year, month, day, weekday;
	printf("Please input the year, month and day:");
	scanf("%d%d%d", &year, &month, &day);
	//judging if the input is valid
	if(month<1 || month>12 || day<1 || day>31 || ( isleap(year)&&month==2 && day>29 ) || 
		(!isleap(year)&&month==2&&day>28))
	{
		printf("Invalid input");
		return 0;
	}
	
	//calculating the day of the week
	if(month==1 || month==2)
	{
		month+=12;year--;
	}
	weekday= (day+2*month+3*(month+1)/5+year+year/4-year/100+year/400) % 7;
	
	//output
	switch(weekday)
	{
		case 0: printf("Monday");break;
		case 1: printf("Tuesday");break;
		case 2: printf("Wednesday");break;
		case 3: printf("Thursday");break;
		case 4: printf("Friday");break;
		case 5: printf("Saturday");break;
		case 6: printf("Sunday");break;
	} 
	return 0;
}
