/*
	Program: Task_1
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-12
	Description: calculating the area of a triangle using Heron's formula
*/
#include<stdio.h>
#include<math.h>

int main()
{
	int a,b,c;// a, b, c represents three sides of a triangle
	float s, t, area;
	printf("Please input three sides of a triangle:");//input prompt 
	scanf("%d%d%d", &a, &b, &c);
	
	//calculate
	s = (a+b+c)/2.0;
	t = s*(s-a)*(s-b)*(s-c);
	if(t>0)
	{
		area = sqrt(t);
		printf("%f\n", area);
	}
	else
	{
		printf("Invalid input! The three sides cannot represent the sides of a triangle.");//display message
	}

	return 0;
}
