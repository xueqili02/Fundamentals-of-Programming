/*
	Program: Task_4
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-12
	Description: calculating the gross pay, the taxes, and the net pay.
*/

#include<stdio.h>
#define pay1 8.75
#define pay2 9.33
#define pay3 10.00
#define pay4 11.20

int main()
{
	int choice, hours;
	float grossPay, tax, netPay;

	printf("Please choose your desired pay rate or action:\n");
	printf("1)$8.75/hr\n2)$9.33/hr\n3)$10.00/hr\n4)$11.20/hr\n5)quit\n");
	//loop to recycle
	for(;;)
	{
		printf("Please input your choice: ");
		scanf("%d", &choice);
		
		//if the input is valid
		if(choice>5 || choice<1)
		{
			printf("This is an invalid input. Please input a number between 1 and 5!\n");
			continue;
		}
		if(choice == 5) break; //break
		if(choice>=1 && choice<=4)
		{
			printf("Please input the working hours:");
			scanf("%d", &hours);
		}
		
		//using switch to select the pay rate
		switch(choice)
		{
			case 1: 
				if(hours<=40)grossPay = pay1 * hours;
				else grossPay = pay1 * 40 + pay1*2.5*(hours - 40);
				
				if(grossPay<=300)tax = 0.15 * grossPay;
				else if(grossPay<=450) tax = 0.15*300+(grossPay-300)*0.2;
				else tax = 0.15*300 + 0.2*150 + 0.25*(grossPay-450);
				
				netPay = grossPay - tax;
				printf("Gross pay: %.2f\nTaxes: %.2f\nNet pay: %.2f\n\n", grossPay, tax, netPay);
				break;
			case 2:
				if(hours<=40)grossPay = pay2 * hours;
				else grossPay = pay2 * 40 + pay2*2.5*(hours - 40);
				
				if(grossPay<=300)tax = 0.15 * grossPay;
				else if(grossPay<=450) tax = 0.15*300+(grossPay-300)*0.2;
				else tax = 0.15*300 + 0.2*150 + 0.25*(grossPay-450);
				
				netPay = grossPay - tax;
				printf("Gross pay: %.2f\nTaxes: %.2f\nNet pay: %.2f\n\n", grossPay, tax, netPay);
				break;
			case 3:
				if(hours<=40)grossPay = pay3 * hours;
				else grossPay = pay3 * 40 + pay3*2.5*(hours - 40);
				
				if(grossPay<=300)tax = 0.15 * grossPay;
				else if(grossPay<=450) tax = 0.15*300+(grossPay-300)*0.2;
				else tax = 0.15*300 + 0.2*150 + 0.25*(grossPay-450);
				
				netPay = grossPay - tax;
				printf("Gross pay: %.2f\nTaxes: %.2f\nNet pay: %.2f\n\n", grossPay, tax, netPay);
				break;
			case 4:
				if(hours<=40)grossPay = pay4 * hours;
				else grossPay = pay4 * 40 + pay4*2.5*(hours - 40);
				
				if(grossPay<=300)tax = 0.15 * grossPay;
				else if(grossPay<=450) tax = 0.15*300+(grossPay-300)*0.2;
				else tax = 0.15*300 + 0.2*150 + 0.25*(grossPay-450);
				
				netPay = grossPay - tax;
				printf("Gross pay: %.2f\nTaxes: %.2f\nNet pay: %.2f\n\n", grossPay, tax, netPay);
				break;
			default:
				break;
		}
	}
	return 0;
}