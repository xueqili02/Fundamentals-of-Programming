/*
	Program: Task_2
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-15
	Description: calculating Pi 
*/

#include<stdio.h>

int a=0,b=0,c=0,d=0;//a第一次得到3.14，b第一次得到3.141，c第一次得到3.1415，d第一次得到3.14159

//判断第一次出现的位置
void judge(double val,int i)
{
	if(val>3.14 && val<3.15 && !a)a=i;
	if(val>3.141 && val<3.142 && !b)b=i;
	if(val>3.1415 && val<3.1416 && !c)c=i;
	if(val>3.14159 && val<3.1416 && !d)d=i;
}

int main()
{
	int limit;
	int cnt=0;//计算次数
	double val=0;
	printf("Please input the limit of the formula's calculating times: ");
	scanf("%d", &limit);
	for(int i=1;i<=limit;i++)
	{
		cnt++;
		//calculate Pi
		if(i%2==1)
			val = val + 4.0 / (2*i-1);
		else
			val = val - 4.0 / (2*i-1);
		judge(val, i);

		printf("terms: %d, the value of Pi: %.7lf\n", cnt, val);
	}
	printf("terms when first getting 3.14: %d\nterms when first getting 3.141: %d\nterms when first getting 3.1415: %d\nterms when first getting 3.14159: %d\n",a,b,c,d);
	return 0;
}