/*
	Program: Task_1
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-15
	Description: calculating the child's total amount of gift and her current age
*/
#include<stdio.h>

int main()
{
	int gift=10, age=10, sum=10;
	
	//calculating
	while(gift <=1000)
	{
		age++;
		gift *= 2;
		sum += gift;
		//condition controlling
		if(gift>1000)
		{
			sum -= gift;
			age--;
		}
	}
	
	//output
	printf("The child's age is: %d\nThe total amount of gift is: %d\n", age, sum);
	return 0;
}