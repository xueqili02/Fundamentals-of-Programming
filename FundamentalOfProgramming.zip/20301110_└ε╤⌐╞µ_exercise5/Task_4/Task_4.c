/*
	Program: Task_4
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-16
	Description: printing the number in two different ways
*/
#include<stdio.h>
#include<math.h>
//计算value的位数
int convert(int value)
{
	int now = value, wei=0;//wei: value的位数
	while(now!=0)
	{
		now = now / 10;
		wei++;
	}
	return wei;
}

int multiple(int num)
{
	int temp=1;
	for(int i=num;i>1;i--)
	{
		temp *= 10;
	}
	return temp;
}

//converting integer to words
void convertIntToWords(int value)
{
	int wei;//储存value的位数
	wei = convert(value);
	for(int i=wei;i>0;i--)
	{
		//分离value的各位并输出相应的英文
		int x, y=multiple(i);
		x=value / y;
		value=value - x*y;
		switch(x){
			case 1: printf("One ");break;
			case 2: printf("Two ");break;
			case 3: printf("Three ");break;
			case 4: printf("Four ");break;
			case 5: printf("Five ");break;
			case 6: printf("Six ");break;
			case 7: printf("Seven ");break;
			case 8: printf("Eight ");break;
			case 9: printf("Nine ");break;
			case 0: printf("Zero ");break;
			default:break;
		}
	}
}

//converting integer to real words
void convertIntToRealWords(int value)
{
	switch(value){
		case 1: printf("One");break;
		case 2: printf("Two");break;
		case 3: printf("Three");break;
		case 4: printf("Four");break;
		case 5: printf("Five");break;
		case 6: printf("Six");break;
		case 7: printf("Seven");break;
		case 8: printf("Eight");break;
		case 9: printf("Nine");break;
		case 10: printf("Ten");break;
		case 11: printf("Eleven");break;
		case 12: printf("Twelve");break;
		case 13: printf("Thirteen");break;
		case 14: printf("Fourteen");break;
		case 15: printf("Fifteen");break;
		case 16: printf("Sixteen");break;
		case 17: printf("Seventeen");break;
		case 18: printf("Eighteen");break;
		case 19: printf("Nineteen");break;
		case 20: printf("Twenty");break;
		case 30: printf("Thirty");break;
		case 40: printf("Forty");break;
		case 50: printf("Fifty");break;
		case 60: printf("Sixty");break;
		case 70: printf("Seventy");break;
		case 80: printf("Eighty");break;
		case 90: printf("Ninty");break;		
	}

	if(value>20 && value<100 && value%10!=0 )
	{
		int a=value/10;
		int temp = value%10;
		switch(a){
			case 2: printf("Twenty ");break;
			case 3: printf("Thirty ");break;
			case 4: printf("Forty ");break;
			case 5: printf("Fifty ");break;
			case 6: printf("Sixty ");break;
			case 7: printf("Seventy ");break;
			case 8: printf("Eighty ");break;
			case 9: printf("Ninty ");break;
		}
		switch(temp){
			case 1: printf("One ");break;
			case 2: printf("Two ");break;
			case 3: printf("Three ");break;
			case 4: printf("Four ");break;
			case 5: printf("Five ");break;
			case 6: printf("Six ");break;
			case 7: printf("Seven ");break;
			case 8: printf("Eight ");break;
			case 9: printf("Nine ");break;
			case 0: printf("Zero ");break;
		}
	}

	else if(value>=100 && value<1000)
	{
		int f, s, t;//百位，十位，个位
		//分离各位
		f=value/100;
		s=value%100/10;
		t=value%10;

		switch(f){
			case 1: printf("One ");break;
			case 2: printf("Two ");break;
			case 3: printf("Three ");break;
			case 4: printf("Four ");break;
			case 5: printf("Five ");break;
			case 6: printf("Six ");break;
			case 7: printf("Seven ");break;
			case 8: printf("Eight ");break;
			case 9: printf("Nine ");break;
		}
		printf("Hundred ");
		
		if(s==0 && t!=0)
		{
			printf("And ");
			switch(t){
				case 1: printf("One ");break;
				case 2: printf("Two ");break;
				case 3: printf("Three ");break;
				case 4: printf("Four ");break;
				case 5: printf("Five ");break;
				case 6: printf("Six ");break;
				case 7: printf("Seven ");break;
				case 8: printf("Eight ");break;
				case 9: printf("Nine ");break;
			}
		}
		if(s!=0 && t==0)
		{
			printf("And ");
			switch(s){
				case 1: printf("Ten");break;
				case 2: printf("Twenty");break;
				case 3: printf("Thirty");break;
				case 4: printf("Forty");break;
				case 5: printf("Fifty");break;
				case 6: printf("Sixty");break;
				case 7: printf("Seventy");break;
				case 8: printf("Eighty");break;
				case 9: printf("Ninty");break;
			}
		}
		if(s!=0 && t!=0)
		{
			printf("And ");
			switch(s){
				case 1:{
					switch(t){
						case 1: printf("Eleven");break;
						case 2: printf("Twelve");break;
						case 3: printf("Thirteen");break;
						case 4: printf("Fourteen");break;
						case 5: printf("Fifteen");break;
						case 6: printf("Sixteen");break;
						case 7: printf("Seventeen");break;
						case 8: printf("Eighteen");break;
						case 9: printf("Nineteen");break;
					}
				}break;
				case 2: printf("Twenty ");break;
				case 3: printf("Thirty ");break;
				case 4: printf("Forty ");break;
				case 5: printf("Fifty ");break;
				case 6: printf("Sixty ");break;
				case 7: printf("Seventy ");break;
				case 8: printf("Eighty ");break;
				case 9: printf("Ninty ");break;
			}
			switch(t){
				case 1: printf("One");break;
				case 2: printf("Two");break;
				case 3: printf("Three");break;
				case 4: printf("Four");break;
				case 5: printf("Five");break;
				case 6: printf("Six");break;
				case 7: printf("Seven");break;
				case 8: printf("Eight");break;
				case 9: printf("Nine");break;
			}
		}
	}
}
int main()
{
	int n;
	printf("If you want to quit, please input a number larger than 1000.\n");
	printf("Please input a number between 0 and 1000: ");
	while(scanf("%d",&n) && n<1000){
		if(n==0)
			{printf("Invalid inpupt! Please input again.");continue;}
		printf("This number is called: ");
		convertIntToWords(n);
		printf("\n");
		printf("This number is also called: ");
		convertIntToRealWords(n);
		printf("\n\n");
	}
	return 0;
}