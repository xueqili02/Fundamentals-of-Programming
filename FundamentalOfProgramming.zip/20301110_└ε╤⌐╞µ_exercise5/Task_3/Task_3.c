/*
	Program: Task_3
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-16
	Description: simple simon game
*/
#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<time.h>
#include<stdbool.h>

int a[10000]={0},b[10000]={0};//a: computer  b: user
int sequence_length=3;

//producing sequence
int sequence_create(int sequence_length)
{
	int seed = time(NULL);
	srand((unsigned int) seed);
	for(int i=0;i<sequence_length;i++)
	{
		printf("%d ", a[i]=rand()%10);
	}
}
//erasing the produced sequence after one second
void erase(int sequence_length)
{
	printf("\r");
	for(int i=1;i<=sequence_length*2;i++)
	{
		printf(" ");
	}
}
//asking user to input the sequence
void input(int sequence_length)
{
	printf("\r");
	printf("Please enter your answer(Don't forget spaces):\n");\
	for(int i=0;i<sequence_length;i++)
	{
		scanf("%d", &b[i]);
	}
}
//wait for one second
int wait(void)
{
	int now = clock();
	for(; clock() - now < CLOCKS_PER_SEC; );
}

int main()
{
	char ask,start;
	
	printf("Welcome to play Simple Simon\nPress enter to start!");
	scanf("%c", &start);
	if(start == '\n')
	{
		for(;;)
		{
			//flag: judge if the sequence is correct; 
			int flag=true, correct_num=0, counter=0, time_taken=0, startTime;
			long long score=0;
			sequence_length=3;
			do
			{
				//increase sequence length every three correct times
				if(correct_num % 3 ==0 && correct_num != 0)
				{
					sequence_length++;
				}

				sequence_create(sequence_length);
				wait();
				erase(sequence_length);
				if(counter==0)startTime=clock();
				input(sequence_length);
				
				for(int i=0;i<sequence_length;i++)
				{
					if(a[i]!=b[i])flag=false;
				}

				if(flag == true)
				{
					printf("Correct!\n");correct_num++;counter++;
				}
				if(flag == false)
				{
					printf("Wrong!\n");
				}
			}while(flag);

			//calculating score
			time_taken = (clock() - startTime)/CLOCKS_PER_SEC;
			score = counter * 100000.0 / time_taken;
			
			printf("Your score is %d\n", score);
			printf("Do you want to play again?(y/n)\n");//ask if the user want to play again
			
			fflush(stdin);
			scanf("%c", &ask);
			ask = tolower(ask);
			if(ask=='y')continue;
			else {break;}
		}
	}
	return 0;
}