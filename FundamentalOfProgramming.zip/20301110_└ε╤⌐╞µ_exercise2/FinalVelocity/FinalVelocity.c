/*
	Program: FinalVelocity
	Name: ��ѩ��
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-9-30
	Description: calculating final velocity and distance
*/

#include<stdio.h>

int main()
{
	float u, a, t, v, s;
	/*u is initial velocity; a is acceleration; 
	t is time; v is final velocity; s is distance*/
	scanf("%f%f%f", &u, &a, &t);
	v = u + a * t;
	s = u * t + 0.5 * a * t * t;
	printf("%f %f", v, s);
	return 0;
}
