/*
	Program: OddorEven
	Name: ��ѩ��
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-9-30
	Description: judging if a number is odd or even
*/

#include<stdio.h>

int main()
{
	int number;
	scanf("%d", &number);
	if(number % 2 == 0)//judging if a nunmber is even 
	{
		printf("%d is even", number);
	}
	else if (number % 2 == 1)//judging if a number is odd
	{
		printf("%d is odd", number);
	}
	return 0;
}
