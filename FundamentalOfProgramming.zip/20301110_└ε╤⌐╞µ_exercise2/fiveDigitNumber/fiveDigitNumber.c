/*
	Name: ��ѩ��
	StudentNumber: 20301110
	Copyright:2020
	Date: 2020-9-30
	Description: seperating a five-digit number into its individual numbers
*/

#include <stdio.h>

int main()
{
	int fiveDigitNumber;
	int a,b,c,d,e;//a����bʮ��c�٣�dǧ��e�� 
	scanf("%d", &fiveDigitNumber);
	a = fiveDigitNumber % 10;
	e = fiveDigitNumber / 10000;
	d = fiveDigitNumber / 1000 % 10;
	c = fiveDigitNumber / 100 % 10;
	b = fiveDigitNumber / 10 % 10;
	printf("%d	%d	%d	%d	%d", e, d, c, b, a);
	return 0;
}
