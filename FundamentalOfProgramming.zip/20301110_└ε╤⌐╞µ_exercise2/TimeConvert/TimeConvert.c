/*
	Program: TimerConvert
	Name: ��ѩ��
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-9-30
	Description: converting from seconds to hours, minutes and seconds
*/

#include<stdio.h>

int main()
{
	int hours, minutes, seconds, initialSeconds;
	scanf("%d", &initialSeconds);
	minutes = initialSeconds / 60;
	seconds = initialSeconds % 60;
	hours = minutes / 60;
	minutes = minutes - hours * 60;//converting from seconds to hours, minutes and seconds
	printf("%d:%d:%d", hours, minutes, seconds);
	return 0;
} 
