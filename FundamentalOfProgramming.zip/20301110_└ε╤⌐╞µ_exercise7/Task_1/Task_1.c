/*
	Program: Task_1
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-11
	Description: calculate amounts and display a table containing prices, units, and amounts
*/
#include<stdio.h>

void getUnits(double units[], int members)
{
	printf("Please input five numbers representing units: ");
	for(int i=0;i<members;i++)
	{
		scanf("%lf",&units[i]);
	}
}

double calcAmount(double *prices, double *units, double *amts, int elms)
{
	for(int i=0;i<elms;i++)
	{
		amts[i] = units[i] * prices[i];
	}
	return *amts;
}

int main()
{
	double prices[5]={9.92, 6.32, 12.63, 5.95, 10.29},units[5],amounts[5],total=0;
	getUnits(units,5);
	calcAmount(prices, units, amounts, 5);
	for(int i=0;i<5;i++)
	{
		total+=amounts[i];
	}
	//print
	printf("Prices  Units   Amount\n");
	printf("------- ------- -------\n");
	for(int i=0;i<5;i++)
	{
		printf("%.2lf\t%.2lf\t%.2lf\n",prices[i], units[i], amounts[i]);
	}
	printf("                -------\n");
	printf("Total: %.2lf\n",total);
	return 0;
}