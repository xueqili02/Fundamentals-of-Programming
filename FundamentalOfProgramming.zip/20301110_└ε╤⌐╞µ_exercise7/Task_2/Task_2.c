/*
	Program: Task_2
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-11
	Description: copy and sort an array and display it
*/
#include<stdio.h>
#include<stdbool.h>

double copy_arr(double *source, double *target, int length)
{
	for(int i=0;i<length;i++)
	{
		target[i] = source[i];
	}
	return *source;
}

bool findMin(double x, double y)
{
	if(x<y)return true;
	else return false;
}
//swap
void swap(double *a, double *b)
{
	double temp;
	temp = *a;
	*a = *b;
	*b = temp;
}
//sort
double sort(double *array, int length)
{
	for(int i=0;i<length-1;i++)
	{
		for(int j=i+1;j<length;j++)
		{
			if(findMin(array[i],array[j]))swap(&array[i],&array[j]);
		}
	}
	return *array;
}
//output
void display_array(double *target, int length)
{
	for(int i=0;i<length;i++)
	{
		printf("%lf ",target[i]);
	}
	printf("\n");
}

int main()
{
	double source[5] = {1.1, 2.2, 3.3, 4.4, 5.5};

	double target [5];

	copy_arr(source, target, 5);

	display_array(target, 5);

	sort(target, 5);

	display_array(source, 5);//for comparing

	display_array(target, 5);

	return 0;
}