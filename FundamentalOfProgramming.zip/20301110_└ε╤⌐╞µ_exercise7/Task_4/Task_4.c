/*
	Program: Task_4
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-11
	Description: judge palindromes
*/
#include<stdio.h>
#include<stdbool.h>
#include<string.h>
#include<ctype.h>

void getCharacter(char str[])
{
	printf("Please input a character: ");
	gets(str);
}

void transfer(char str[], char cmp[], int length)
{
	int j=0;
	for(int i=0;i<length;i++)
	{
		if( (str[i]>=0 && str[i]<=9) || (str[i]>='a' && str[i]<='z') )
		{
			cmp[j] = str[i];
			j++;
		}
		else continue;
	}
}

bool testPalindrome(char cmp[],int length)
{
	bool flag=true;
	for(int i=0;i<length/2;i++)
	{
		if(cmp[i] != cmp[length-i-1])flag=false;
	}
	if(!flag)return 0;
	else return 1;
}

int main()
{
	char str[10000],cmp[10000];
	int length_str,length_cmp;
	bool flag=true;

	getCharacter(str);

	length_str = strlen(str);

	for(int i=0;i<length_str;i++)
	{
		str[i] = tolower(str[i]);//tranfer the array to lower case
	}

	transfer(str, cmp, length_str);
	length_cmp = strlen(cmp);

	if(testPalindrome(cmp, length_cmp))
		printf("is a Palindrome\n");
	else
		printf("Not a Palindrome\n");
	return 0;
}