/*
	Program: Task_4
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-11
	Description: remove the given character from the string
*/
#include<stdio.h>
#include<string.h>

void removeChar(char *string, char ch)
{
	char temp[10000];
	int j=0;
	int length = strlen(string);
	for(int i=0;i<length;i++)
	{
		if(string[i] == ch)
		{
			string[i] = ' ';
		}
		else
		{
			temp[j] = string[i];
			j++;
		}
	}
	strcpy(string,temp);
}

int main()
{
	char message[10000],ch;
	printf("Please input a string: ");
	gets(message);
	printf("Please input a character you want to remove: ");
	ch = getchar();//input
	removeChar(message, ch);
	puts(message);
	return 0;
}