/*
	Program: Task_3
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-11
	Description: simulate the rolling of two dice and display the percentage of each sum  
*/
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>

void calc(float *percent,int *total)
{
	for(int i=2;i<=12;i++)
	{
		percent[i] = total[i] / 360000.0;
	}
}

void print_percent(float *percent)
{
	for(int i=2;i<=12;i++)
	{
		printf("The percentage of sum %d is: %f%%\n",i,percent[i]*100);
	}
}

int main()
{
	int total[13];
	int n,m,sum,seed=time(NULL);
	float percent[13];
	//random number
	srand((unsigned int)seed);

	memset(total,0,sizeof(total));

	for(int i=1;i<=360000;i++)
	{	
		n=rand()%6+1;// produce 1-7
		m=rand()%6+1;
		sum = n+m;
		switch(sum)
		{
			case 2: total[2]++;break;
			case 3:	total[3]++;break;
			case 4: total[4]++;break;
			case 5: total[5]++;break;
			case 6: total[6]++;break;
			case 7: total[7]++;break;
			case 8: total[8]++;break;
			case 9: total[9]++;break;
			case 10: total[10]++;break;
			case 11: total[11]++;break;
			case 12: total[12]++;break;
		}
	}
	calc(percent,total);
	print_percent(percent);
	return 0;
}