﻿#ifndef STUDENT_SERVICE_H
#define STUDENT_SERVICE_H

void add_student(Student *_stu_info);
Student *search_student(char *input_name);
void change_student();
Student* delete_student();
Student* insertScore(Student *newHead,Student *Node);
Student* insertName(Student *newHead,Student *Node);
Student* sort_student();

#endif