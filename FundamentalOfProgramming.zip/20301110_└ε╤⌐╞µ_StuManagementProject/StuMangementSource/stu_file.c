﻿#include "global.h"
#include <stdio.h>
#include <stdlib.h>

int count;
Student *stu;

void get_count()
{
	char ch;
	FILE *fp;
	fp = fopen("count.txt","r");
	if(fp==NULL)
	{
		printf("File cannot be found.\n");exit(1);
	}
	fscanf(fp,"%d",&count);
	fclose(fp);
}

void read_file()
{
	FILE* fp;
	fp = fopen("student.txt", "r");
	Student *head=NULL;
	Student *first=(Student*)malloc(sizeof(Student));
	for(int i=1;i<=count;i++)
	{
		Student *node=(Student*)malloc(sizeof(Student));
		if(node==NULL)
		{
			printf("Allocation failed\n");exit(1);
		}
		if(head==NULL)head=node;
		node->next=NULL;
		fscanf(fp, "%s %s %c %d %f %f %f",
				node->num,node->name,&node->sex,&node->age,&node->cscore,&node->mscore,&node->escore);
		first->next=node;
		first=first->next;
	}
	stu=head;
	fclose(fp);
}
void write_file()
{
	FILE *fp,*cnt;
	fp = fopen("student.txt", "w");
	Student *temp=stu;
	while(temp)
	{
		fprintf(fp, "%s %s %c %d %f %f %f",
				temp->num,temp->name,temp->sex,temp->age,temp->cscore,temp->mscore,temp->escore);
		temp=temp->next;
		fputc('\n',fp);
	}
	cnt = fopen("count.txt","w");
	fprintf(cnt,"%d",count);
	printf("You have saved the information\n\n");
	fclose(fp);
	fclose(cnt);
}