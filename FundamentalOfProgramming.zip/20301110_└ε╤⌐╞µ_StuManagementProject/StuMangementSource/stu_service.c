﻿#include "global.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

void add_student(Student *sStu)
{
	Student *temp=sStu,*Prev;
	while(temp)
	{
		Prev=temp;
		temp=temp->next;
	}
	printf("Please enter the information of the student you want to add.\nEvery information is divided by enter\n");
	Student *node=(Student*)malloc(sizeof(Student));
	
	fflush(stdin);count++;
	gets(node->num);gets(node->name);node->sex=getchar();
	scanf("%d",&node->age);scanf("%f",&node->cscore);scanf("%f",&node->mscore);scanf("%f",&node->escore);	
	
	node->next=NULL;
	Prev->next=node;
	
	printf("You have added a student's information\n\n");
}

Student *search_student(char *input_name)
{
	bool flag=false;
	Student *temp=stu;
	while(temp)
	{	
		if(strcmp(temp->name,input_name)==0)
		{
			printf("The information is as follows:\n");
			printf("%s\t%s\t%c\t%d\t%.1f\t%.1f\t%.1f\n\n",
					temp->num,temp->name,temp->sex,temp->age,temp->cscore,temp->mscore,temp->escore);flag=true;break;
		}
		temp=temp->next;
		
	}
	if(!flag)printf("Name does not exist.\n\n");
}

void change_student()
{
	char name[30];
	printf("Please input the name of the student.\n");
	fflush(stdin);
	gets(name);
	Student *temp=stu;
	while(temp)
	{	
		if(strcmp(temp->name,name)==0)
		{
			int c;
			printf("Please input which info you want to change.\n");
			printf("1 num; 2 name; 3 sex; 4 age; 5 cscore; 6 mscore; 7 escore\n");
			fflush(stdin);scanf("%d",&c);fflush(stdin);
			switch(c)
			{
				case 1: gets(temp->num);break;
				case 2: gets(temp->name);break;
				case 3: temp->sex=getchar();break;
				case 4: scanf("%d",&temp->age);break;
				case 5: scanf("%f",&temp->cscore);break;
				case 6: scanf("%f",&temp->mscore);break;
				case 7: scanf("%f",&temp->escore);break;
			}
			printf("You have changed a student's information\n\n");
			return;
		}
		temp=temp->next;
	}
	printf("Student does not exist.\n\n");
}

Student* delete_student()
{
	Student *temp=stu,*pre=stu;
	char name[30];
	printf("Please input the name of the student you want to delete\n");
	fflush(stdin);
	gets(name);
	while(temp)
	{	
		if(strcmp(temp->name,name)==0)
		{
			if(temp==stu)
			{
				stu=temp->next;
			}
			else pre->next=temp->next;
			count--;
			printf("You have deleted a student's information\n\n");
			return stu;
		}
		pre=temp;
		temp=temp->next;
	}
	printf("This student does not exist.\n\n");
	return stu;
}

Student* insertScore(Student *newHead,Student *Node)
{
	Student *Prev,*Next=newHead;
	Student *Head=newHead;
	if(Head==NULL)
	{
		Head=Node;
		Node->next=NULL;
		return Head;
	}
	while(Next!=NULL && Node->cscore > Next->cscore)
	{
		Prev=Next;
		Next=Next->next;
	}
	if(Next==NULL)
	{
		Prev->next=Node;
		Node->next=NULL;
	}
	else
	{
		if(Head==Next)Head=Node;
		else Prev->next=Node;
		Node->next=Next;
	}
	return Head;
}
Student* insertName(Student *newHead,Student *Node)
{
	Student *Prev,*Next=newHead;
	Student *Head=newHead;
	if(Head==NULL)
	{
		Head=Node;
		Node->next=NULL;
		return Head;
	}
	while(Next!=NULL && strcmp(Node->name,Next->name)>0 )
	{
		Prev=Next;
		Next=Next->next;
	}
	if(Next==NULL)
	{
		Prev->next=Node;
		Node->next=NULL;
	}
	else
	{
		if(Head==Next)Head=Node;
		else Prev->next=Node;
		Node->next=Next;
	}
	return Head;
}
Student* sort_student()
{
	Student *Head=stu,*newHead=NULL;
	Student *p=Head,*Next;
	int c;
	printf("Please input what you want to sort by.\n");
	printf("1 name; 2 cscore\n");
	fflush(stdin);scanf("%d",&c);
	if(c==1)
	{
		while(p!=NULL)
		{
			Next=p->next;
			newHead=insertName(newHead,p);
			p=Next;
		}
		printf("Information has been sorted by name.\n\n");
		return newHead;
	}
	else if(c==2)
	{
		while(p!=NULL)
		{
			Next=p->next;
			newHead=insertScore(newHead,p);
			p=Next;
		}
		printf("Information has been sorted by Cscore.\n\n");
		return newHead;
	}
	else 
	{
		printf("Invalid choice!\n");
		return stu;
	}
}