﻿/*
	Program: StuManagement
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-12-10
	Description: implementing a student information management
*/
#include <stdio.h>
#include <stdlib.h>
#include "global.h"
#include "stu_service.h"
#include "stu_file.h"

void displaySystemName()
{
	printf("************************\n");
	printf("Student Information Management\n");
	printf("************************\n");
}
void displayMenu()
{
	printf("**********Menu**********\n");
	printf("1 Add Student Info\n2 Display Student Info\n3 Search Student Info\n4 Change Student Info\n5 Delete Student Info\n6 Sort Student Info\n7 Save Student Info\n0 Exit System\n");
	printf("Please enter your option (0~7): ");fflush(stdin);
}
void displayChoice(int choice)
{
	switch(choice)
	{
		case 1: printf("You select to Add Student Info.\n");break;
		case 2: printf("You select to Display Student Info.\n");break;
		case 3: printf("You select to Search Student Info.\n");break;
		case 4: printf("You select to Change Student Info.\n");break;
		case 5: printf("You select to Delete Student Info.\n");break;
		case 6: printf("You select to Sort Student Info.\n");break;
		case 7: printf("You select to Save Student Info.\n");break;
		case 0: printf("You select to Exit System.\n");break;
	}	
}
void add()
{
	add_student(stu);
}
void display()
{
	Student *temp=stu;
	while(temp)
	{
		printf("%s %s %c %d %.1f %.1f %.1f\n",
				temp->num,temp->name,temp->sex,temp->age,temp->cscore,temp->mscore,temp->escore);
		temp=temp->next;
	}
}
void search()
{
	char input_name[30];
	printf("Please input the name.\n");
	fflush(stdin);
	gets(input_name);
	search_student(input_name);
}
void change()
{
	change_student();
}
void del()
{
	stu=delete_student();
}
void sort()
{
	stu=sort_student();
}
int main() {
	int choice=-1;
	displaySystemName();
	get_count();
	read_file();
	while(choice!=0)
	{
		displayMenu();
		fflush(stdin);
		scanf("%d",&choice);
		if(choice<0 || choice>7)
		{
			printf("Invalid Choice! Please input again!\n");
			continue;
		}
		displayChoice(choice);
		switch(choice)
		{
			case 1: add();break;
			case 2: display();break;
			case 3: search();break;
			case 4: change();break;
			case 5: del();break;
			case 6: sort();break;
			case 7: write_file();break;
			case 0: break;
			default: break;
		}
	}
	free(stu);
	return 0;
}