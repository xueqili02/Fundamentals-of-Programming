﻿#ifndef STUDENT_FILE_H
#define STUDENT_FILE_H

void get_count();
void read_file();
void write_file();

#endif