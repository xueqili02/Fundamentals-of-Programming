﻿#ifndef STUDENT_GLOBAL_H
#define STUDENT_GLOBAL_H
#define STU_MAX 300

typedef struct Student
{
	char num[10],name[30],sex;
	int age;
	float cscore,mscore,escore;
	struct Student *next;
}Student;

extern int count;
extern Student *stu;

#endif
