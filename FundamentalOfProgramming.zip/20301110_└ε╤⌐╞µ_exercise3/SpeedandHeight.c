/*
	Program: SpeedandHeight
	Name: ��ѩ��
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-7
	Description: calculating speed and bounce height on earth and moon
*/

#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#define GEarth 9.81
#define GMoon  1.67

int main()
{
	float initial_height, rebound_height, speed_earth, speed_moon;
	int i=1;
	
	printf("Please input the initial height of the ball:");//input prompt
	scanf("%f", &initial_height);
	
	while(i<=3) //using loop to calculate three times
	{
		speed_earth = sqrt( 2*GEarth*initial_height );
		speed_moon  = sqrt( 2*GMoon*initial_height);
		initial_height *= 2.0/3;
		printf( "The speed on earth:%f The speed on moon:%f The rebound height:%f", 
				speed_earth, speed_moon, initial_height);
		printf("\n"); 
		i++;
	} 
	
	return 0;
}
