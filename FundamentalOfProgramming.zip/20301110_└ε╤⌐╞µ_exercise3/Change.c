/*
	Program: Change
	Name: ��ѩ��
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-7
	Description: calculating the dollar remaining after an amount paid, 
				representing by dollars,quarters,dimes,nickels,pennies
*/

#include<stdio.h>

int main()
{
	int dollars=0, quarters=0, dimes=0, nickels=0, pennies=0;//representing the number of different kinds of coins
	float money, bill, change;//the money you paid; the bill you should pay; the change you will get
	
	printf("Please input the money paid and the bill:");//input prompt
	scanf("%f%f", &money, &bill);
	
	//calculate
	change = (money - bill) * 100;
	dollars = change / 100;
	change -= dollars * 100;
	quarters = change / 25;
	change -= quarters * 25;
	dimes = change / 10;
	change -= dimes * 10;
	nickels = change / 5;
	change -=nickels * 5;
	pennies = change;
 
	printf("dollars:%d\nquarters:%d\ndimes:%d\nnickels:%d\npennies:%d", 
			dollars, quarters, dimes, nickels, pennies);
	return 0;
} 
