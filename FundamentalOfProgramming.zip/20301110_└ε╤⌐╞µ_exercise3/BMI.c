/*
	Program: BMI
	Name: ��ѩ��
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-7
	Description: calculating the BMI of an user and display his health condition.
*/
#include<stdio.h>

int main()
{
	float weightInKilograms, heightInMeters, BMI;
	
	printf("Please input the weight in kilograms and the height in meters:");//input prompt
	scanf("%f%f", &weightInKilograms, &heightInMeters);
	
	BMI = weightInKilograms/(heightInMeters*heightInMeters);//calculating the BMI
	
	printf("The user's BMI is %.1f\n", BMI);
	if(BMI < 18.5)printf("The user is underweight");
	else if(BMI >= 18.5 && BMI < 24.95)printf("The user is normal");
	else if(BMI >= 24.95 && BMI < 29.95)printf("The user is overweight");
	else
	{
		printf("The user is obese");
	}
	return 0;
}
