/*
	Program: Distance
	Name: ��ѩ��
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-10-7
	Description: calculating the distance between two places and rounding the number to the nearest integer
*/
#include<stdio.h>
#include<math.h>

int main()
{
	int x, y;
	float distance;
	
	printf("Please input the values of x and y:");//input prompt
	scanf("%d%d", &x, &y);
	
	distance = sqrt(x*x + y*y);//calculating the distance
	
	distance = (int)(distance + 0.5);//rounding the distance to an integer
	
	printf("%.0f", distance);
	return 0;
}
