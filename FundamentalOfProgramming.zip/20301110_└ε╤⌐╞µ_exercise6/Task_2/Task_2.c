/*
	Program: Task_2
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-1
	Description: converting seconds to the form of hours, minutes, and seconds
*/
#include<stdio.h>
//convert time using pointers
int convertTime(int seconds, int *hours, int *minute, int *sec)
{
	int x,y,z;
	x = seconds/3600;
	y = (seconds - 3600*x)/60;
	z = seconds - 3600*x - 60*y;
	//printf("%d %d %d\n",x,y,z);
	*hours = x;
	*minute = y;
	*sec = z;
}

int main()
{
	int time,hours,minute,sec;

	printf("Please input seconds: ");
	scanf("%d", &time);
	
	convertTime(time, &hours, &minute, &sec);//call the function
	
	printf("hours: %d\nminutes: %d\nseconds: %d\n", hours, minute, sec);
	return 0;
}