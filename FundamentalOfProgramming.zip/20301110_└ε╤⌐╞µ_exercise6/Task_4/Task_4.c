/*
	Program: Task_4
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-2
	Description: printing a year's full calendar
*/
#include<stdio.h>
#include<stdbool.h>

//instructions
void GiveInstructions()
{
	printf("This program displays a calendeer for a full year.\nThe year must not be before 1900.\n");
}

//user input
int GetYearFromUser()
{
	int y;
	for(;;)
	{
		printf("Which year? ");
		scanf("%d",&y);
		if(y<1900)
		{
			printf("Please input again! The year must be after 1900!\n");
			continue;
		}
		else break;
	}
}

//judging leap year
bool isLeapYear(int year)
{
	if( (year%400==0) || (year%4==0 && year%100!=0) )return true;
	return false;
}

//print
void PrintCalendar(int year)
{
	int weekday=1,days;
	days = year-1+(year-1)/400+(year-1)/4-(year-1)/100;//calculating days
	for(int i=1;i<=12;i++)
	{
		weekday = (1+days)%7;
		printf("    ");
		switch(i)
		{
			case 1: printf("January %d\t\n",year);break;
			case 2: printf("February %d\t\n",year);break;
			case 3: printf("March %d\t\n",year);break;
			case 4: printf("April %d\t\n",year);break;
			case 5: printf("May %d\t\n",year);break;
			case 6: printf("June %d\t\n",year);break;
			case 7: printf("July %d\t\n",year);break;
			case 8: printf("August %d\t\n",year);break;
			case 9: printf("September %d\t\n",year);break;
			case 10: printf("October %d\t\n",year);break;
			case 11: printf("November %d\t\n",year);break;
			case 12: printf("December %d\t\n",year);break;
		}
		printf(" Su Mo Tu We Th Fr Sa\n");
		int whitespace=3 * weekday,date=1,daynum,cnt=weekday;
		for(int i=1;i<=whitespace;i++)printf(" ");

		//judging how many days a month has
		if(i==1 || i==3 || i==5 || i==7 || i==8 || i==10 || i==12)daynum=31;
		else if(i==4 || i==6 || i==9 || i==11)daynum=30;
		else if(i==2 && isLeapYear(year))daynum=29;
		else daynum=28;

		for(int date=1;date<=daynum;date++)
		{
			if(date<=9)
			{
				printf("  ");printf("%d",date);cnt++;days++;
			}
			else
			{
				printf(" %d",date);cnt++;days++;
			}

			//switch to a new line every seven times
			if(cnt==7)
			{
				printf("\n");cnt=0;
			}
			if(date==daynum)printf("\n\n");//switch to a new line at the end of a month
		}
	}	
}



int main() 
{
	int year;

	GiveInstructions(); /*prints out instructions to the user*/

	year = GetYearFromUser(); /*reads in a year from the user*/

	PrintCalendar(year); /* prints a calendar for an entire year*/
	
	return 0;
}