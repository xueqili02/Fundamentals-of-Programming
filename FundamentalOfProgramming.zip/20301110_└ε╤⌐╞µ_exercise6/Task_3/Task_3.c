/*
	Program: Task_3
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-1
	Description: transforming a decimal integer into a n-base(2-16) integer
*/
#include<stdio.h>

void to_base_n(int num, int base)
{
	int temp;
	temp = num%base;
	if(num/base!=0)
	{
		to_base_n(num/base, base);//recursion
	}
	if(temp>=0 && temp<=9)
	{
		printf("%d",temp);
	}
	else
	{
		//if the digit is larger than 10, transform it into capital letters
		switch(temp)
		{
			case 10: printf("A");break;
			case 11: printf("B");break;
			case 12: printf("C");break;
			case 13: printf("D");break;
			case 14: printf("E");break;
			case 15: printf("F");break;
		}
	}
}

int main()
{
	int n,base;
	printf("Please input a decimal integer and a base(between 2 and 16): ");
	scanf("%d%d",&n,&base);
	to_base_n(n,base);
	printf("\n");
	return 0;
}