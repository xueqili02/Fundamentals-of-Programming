/*
	Program: Task_5_edition2
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-1
	Description: implementing CAI Project edition 2
*/
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<time.h>

void randomResponse(bool flag);
bool wrong_multiplication(int a,int b,bool flag,int choice);
void exercise_2();

int main()
{
	char start;
	printf("Please press enter to start: ");
	while(scanf("%c",&start) && start=='\n')
	{
		exercise_2();
	}
	return 0;
}

//implementing random response
void randomResponse(bool flag)
{
	int temp,seed=time(NULL);
	srand((unsigned int)seed);
	temp=rand()%4+1;
	if(flag)
	{	
		switch(temp)
		{
			case 1:printf("Very good!\n");break;
			case 2:printf("Excellent!\n");break;
			case 3:printf("Nice work!\n");break;
			case 4:printf("Keep up the good work!\n");break;
		}
	}
	else
	{
		switch(temp)
		{
			case 1:printf("No. Please try again!");break;
			case 2:printf("Wrong. Try once more");break;
			case 3:printf("Don't give up");break;
			case 4:printf("No. Keep trying");break;
		}
	}
}

//judge if multiplication is right
bool wrong_multiplication(int a,int b,bool flag,int choice)
{
	int ans;
	randomResponse(flag);
	scanf("%d",&ans);
	if(ans==a*b)return true;
	else
		return false;
}

void exercise_2()
{
	bool flag;
	int temp[3],ans,seed=time(NULL);
	srand((unsigned int) seed);
	for(int i=1;i<=2;i++)
	{
		printf("%d ",temp[i]=rand()%9+1);
		if(i==1)printf("X ");
		if(i==2)printf("= ");

	}
	scanf("%d",&ans);
	if(ans==temp[1]*temp[2])
	{
		flag=true;
		randomResponse(flag);//random response
		exercise_2();
	}
	else
	{
		flag=false;
		while(1)
		{
			if(wrong_multiplication(temp[1],temp[2],flag,2))
			{
				randomResponse(!flag);//random response
				exercise_2();
				break;
			}
			else
			{
				continue;
			}
		}
		exercise_2();
	}
}
