/*
	Program: Task_5_edition5
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-2
	Description: implementing CAI Project edition 5
*/
#include<stdio.h>
#include<stdbool.h>
#include<time.h>
#include<stdlib.h>

void randomResponse(bool flag);

bool wrong_multiplication(int a,int b,bool flag,int choice);
bool wrong_subtraction(int a,int b,bool flag,int choice);
bool wrong_addition(int a,int b,bool flag,int choice);

int level(int difficulty);
void judge_5(int correct_num, int incorrect_num, int num, int difficulty,int type);

void exercise_addition(int num,int correct_num, int incorrect_num,int difficulty,int type);
void exercise_subtraction(int num,int correct_num, int incorrect_num,int difficulty,int type);
void exercise_multiplication(int num,int correct_num, int incorrect_num,int difficulty,int type);
void exercise_mixture(int num,int correct_num, int incorrect_num,int difficulty,int type);
void exercise_5(int num,int correct_num, int incorrect_num,int difficulty,int type);

int main()
{
	char start;
	int difficulty,type;
	printf("Please press enter to start: ");
	while(scanf("%c",&start) && start=='\n')
	{
		printf("Please input type and difficulty level: ");
		scanf("%d%d",&type,&difficulty);
		exercise_5(0,0,0,difficulty,type);
	}
	return 0;
}

void randomResponse(bool flag)
{
	int temp,seed=time(NULL);
	srand((unsigned int)seed);
	temp=rand()%4+1;
	if(flag)
	{	
		switch(temp)
		{
			case 1:printf("Very good!\n");break;
			case 2:printf("Excellent!\n");break;
			case 3:printf("Nice work!\n");break;
			case 4:printf("Keep up the good work!\n");break;
		}
	}
	else
	{
		switch(temp)
		{
			case 1:printf("No. Please try again!");break;
			case 2:printf("Wrong. Try once more");break;
			case 3:printf("Don't give up");break;
			case 4:printf("No. Keep trying");break;
		}
	}
}

bool wrong_multiplication(int a,int b,bool flag,int choice)
{
	int ans;
	randomResponse(flag);
	scanf("%d",&ans);
	if(ans==a*b)return true;
	else
		return false;
}

bool wrong_subtraction(int a,int b,bool flag,int choice)
{
	int ans;
	switch(choice)
	{
		case 1:printf("No. Please try again. ");break;
		case 2:randomResponse(flag);break;
	}
	scanf("%d",&ans);
	if(ans==a-b)return true;
	else
		return false;
}

bool wrong_addition(int a,int b,bool flag,int choice)
{
	int ans;
	switch(choice)
	{
		case 1:printf("No. Please try again. ");break;
		case 2:randomResponse(flag);break;
	}
	scanf("%d",&ans);
	if(ans==a+b)return true;
	else
		
		return false;
}

int level(int difficulty)
{
	int n=1;
	for(int i=1;i<=difficulty;i++)
	{
		n*=10;
	}
	return n;
}

void judge_5(int correct_num, int incorrect_num, int num, int difficulty,int type)
{
	float percent;
	percent = correct_num*1.0 / num;
	printf("%f\n",percent);
	if(percent<0.75)
	{
		printf("Please ask your teacher for extra help.\n");
		exercise_5(0,0,0,difficulty,type);
	}
	else
	{
		printf("Congratulations, you are ready to go to the next level!\n");
		exercise_5(0,0,0,difficulty,type);
	}
}
//addition
void exercise_addition(int num,int correct_num, int incorrect_num,int difficulty,int type)
{
	if(num==10)
	{
		judge_5(correct_num, incorrect_num, num, difficulty,type);
	}
	bool flag;
	int temp[3],ans,seed=time(NULL),digit;
	digit=level(difficulty);
	srand((unsigned int) seed);
	if(difficulty==1)
	{
		for(int i=1;i<=2;i++)
		{
			printf("%d ",temp[i]=rand()%9+1);
			if(i==1)printf("+ ");
			if(i==2)printf("= ");
		}
	}
	else
	{
		for(int i=1;i<=2;i++)
		{
			printf("%d ",temp[i]=rand()%(digit-digit/10)+digit/10);
			if(i==1)printf("+ ");
			if(i==2)printf("= ");
		}
	}
	scanf("%d",&ans);

	if(ans==temp[1]+temp[2])
	{
		flag=true;
		num++;
		correct_num++;
		randomResponse(flag);
		exercise_5(num,correct_num,incorrect_num,difficulty,type);
	}
	else
	{
		flag=false;
		num++;
		incorrect_num++;
		while(1)
		{
			if(num==10)
			{
				exercise_5(num,correct_num,incorrect_num,difficulty,type);
			}
			if(wrong_addition(temp[1],temp[2],flag,2))
			{
				num++;
				correct_num++;
				exercise_5(num,correct_num,incorrect_num,difficulty,type);
				break;
			}
			else
			{
				num++;
				incorrect_num++;
				continue;
			}
		}

	}
}
//subtraction
void exercise_subtraction(int num,int correct_num, int incorrect_num,int difficulty,int type)
{
	if(num==10)
	{
		judge_5(correct_num, incorrect_num, num, difficulty,type);
	}
	bool flag;
	int temp[3],ans,seed=time(NULL),digit;
	digit=level(difficulty);
	srand((unsigned int) seed);
	if(difficulty==1)
	{
		for(int i=1;i<=2;i++)
		{
			printf("%d ",temp[i]=rand()%9+1);
			if(i==1)printf("- ");
			if(i==2)printf("= ");
		}
	}
	else
	{
		for(int i=1;i<=2;i++)
		{
			printf("%d ",temp[i]=rand()%(digit-digit/10)+digit/10);
			if(i==1)printf("- ");
			if(i==2)printf("= ");
		}
	}
	scanf("%d",&ans);

	if(ans==temp[1]-temp[2])
	{
		flag=true;
		num++;
		correct_num++;
		randomResponse(flag);
		exercise_5(num,correct_num,incorrect_num,difficulty,type);
	}
	else
	{
		flag=false;
		num++;
		incorrect_num++;
		while(1)
		{
			if(num==10)
			{
				exercise_5(num,correct_num,incorrect_num,difficulty,type);
			}
			if(wrong_subtraction(temp[1],temp[2],flag,2))
			{
				num++;
				correct_num++;
				exercise_5(num,correct_num,incorrect_num,difficulty,type);
				break;
			}
			else
			{
				num++;
				incorrect_num++;
				continue;
			}
		}

	}
}
//multiplication
void exercise_multiplication(int num,int correct_num, int incorrect_num,int difficulty,int type)
{
	if(num==10)
	{
		judge_5(correct_num, incorrect_num, num, difficulty,type);
	}
	bool flag;
	int temp[3],ans,seed=time(NULL),digit;
	digit=level(difficulty);
	srand((unsigned int) seed);
	if(difficulty==1)
	{
		for(int i=1;i<=2;i++)
		{
			printf("%d ",temp[i]=rand()%9+1);
			if(i==1)printf("X ");
			if(i==2)printf("= ");
		}
	}
	else
	{
		for(int i=1;i<=2;i++)
		{
			printf("%d ",temp[i]=rand()%(digit-digit/10)+digit/10);
			if(i==1)printf("X ");
			if(i==2)printf("= ");
		}
	}
	scanf("%d",&ans);

	if(ans==temp[1]*temp[2])
	{
		flag=true;
		num++;
		correct_num++;
		randomResponse(flag);
		exercise_5(num,correct_num,incorrect_num,difficulty,type);
	}
	else
	{
		flag=false;
		num++;
		incorrect_num++;
		while(1)
		{
			if(num==10)
			{
				exercise_5(num,correct_num,incorrect_num,difficulty,type);
			}
			if(wrong_multiplication(temp[1],temp[2],flag,2))
			{
				num++;
				correct_num++;
				exercise_5(num,correct_num,incorrect_num,difficulty,type);
				break;
			}
			else
			{
				num++;
				incorrect_num++;
				continue;
			}
		}

	}
}
//mixed calculation
void exercise_mixture(int num,int correct_num, int incorrect_num,int difficulty,int type)
{
	int seed=time(NULL),arithmetic;
	srand((unsigned int)seed);
	arithmetic = rand()%3+1;
	switch(arithmetic)
	{
		case 1: exercise_addition(num,correct_num,incorrect_num,difficulty,type);break;
		case 2: exercise_subtraction(num,correct_num,incorrect_num,difficulty,type);break;
		case 3: exercise_multiplication(num,correct_num,incorrect_num,difficulty,type);break;
		case 4: exercise_mixture(num,correct_num,incorrect_num,difficulty,type);break;
	}
}

void exercise_5(int num,int correct_num, int incorrect_num,int difficulty,int type)
{
	switch(type)
	{
		case 1: exercise_addition(num,correct_num,incorrect_num,difficulty,type);break;
		case 2:	exercise_subtraction(num,correct_num,incorrect_num,difficulty,type);break;
		case 3: exercise_multiplication(num,correct_num,incorrect_num,difficulty,type);break;
		case 4: exercise_mixture(num,correct_num,incorrect_num,difficulty,type);break;
	}
}