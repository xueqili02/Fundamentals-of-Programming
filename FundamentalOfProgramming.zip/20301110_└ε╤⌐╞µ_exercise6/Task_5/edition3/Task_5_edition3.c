/*
	Program: Task_5_edition3
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-1
	Description: implementing CAI Project edition 3
*/
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<stdbool.h>

void exercise_3(int num,int correct_num,int incorrect_num);
void judge_3(int correct_num, int incorrect_num, int num);
void randomResponse(bool flag);
bool wrong_multiplication(int a,int b,bool flag,int choice);

int main()
{
	char start;
	printf("Please press enter to start: ");
	while(scanf("%c",&start) && start=='\n')
	{
		exercise_3(0,0,0);
	}
	return 0;
}

void randomResponse(bool flag)
{
	int temp,seed=time(NULL);
	srand((unsigned int)seed);
	temp=rand()%4+1;
	if(flag)
	{	
		switch(temp)
		{
			case 1:printf("Very good!\n");break;
			case 2:printf("Excellent!\n");break;
			case 3:printf("Nice work!\n");break;
			case 4:printf("Keep up the good work!\n");break;
		}
	}
	else
	{
		switch(temp)
		{
			case 1:printf("No. Please try again!");break;
			case 2:printf("Wrong. Try once more");break;
			case 3:printf("Don't give up");break;
			case 4:printf("No. Keep trying");break;
		}
	}
}

bool wrong_multiplication(int a,int b,bool flag,int choice)
{
	int ans;
	randomResponse(flag);
	scanf("%d",&ans);
	if(ans==a*b)return true;
	else
		return false;
}

//calculate the percentage that are correct
void judge_3(int correct_num, int incorrect_num, int num)
{
	float percent;
	percent = correct_num*1.0 / num;
	printf("%f\n",percent);
	if(percent<0.75)
	{
		printf("Please ask your teacher for extra help.\n");
		exercise_3(0,0,0);//reset
	}
	else
	{
		printf("Congratulations, you are ready to go to the next level!\n");
		exercise_3(0,0,0);//reset
	}
}

void exercise_3(int num,int correct_num,int incorrect_num)
{
	//calculate every 10 inputs
	if(num==10)
	{
		judge_3(correct_num, incorrect_num, num);
	}
	bool flag;
	int temp[3],ans,seed=time(NULL);
	srand((unsigned int) seed);
	for(int i=1;i<=2;i++)
	{
		printf("%d ",temp[i]=rand()%9+1);
		if(i==1)printf("X ");
		if(i==2)printf("= ");

	}
	scanf("%d",&ans);
	if(ans==temp[1]*temp[2])
	{
		flag=true;
		num++;
		correct_num++;
		randomResponse(flag);
		exercise_3(num,correct_num,incorrect_num);
	}
	else
	{
		flag=false;
		num++;
		incorrect_num++;
		while(1)
		{
			if(num==10)
			{
				exercise_3(num,correct_num,incorrect_num);
			}
			if(wrong_multiplication(temp[1],temp[2],flag,2))
			{
				num++;
				correct_num++;
				exercise_3(num,correct_num,incorrect_num);
				break;
			}
			else
			{
				num++;
				incorrect_num++;
				continue;
			}
		}
	}
}