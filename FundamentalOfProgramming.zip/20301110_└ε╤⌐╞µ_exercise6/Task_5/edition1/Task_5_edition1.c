/*
	Program: Task_5_edition1
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-1
	Description: implementing CAI Project edition 1
*/
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<time.h>

void exercise_1();
bool wrong_multiplication(int a,int b,bool flag,int choice);

int main()
{
	char start;
	printf("Please press enter to start: ");
	while(scanf("%c",&start) && start=='\n')
	{
		exercise_1();
	}
	return 0;
}

//judge if multiplication is right
bool wrong_multiplication(int a,int b,bool flag,int choice)
{
	int ans;
	printf("No. Please try again!");
	scanf("%d",&ans);
	if(ans==a*b)return true;
	else
		return false;
}

void exercise_1()
{
	bool flag;
	int temp[3],ans,seed=time(NULL);
	srand((unsigned int) seed);
	for(int i=1;i<=2;i++)
	{
		printf("%d ",temp[i]=rand()%9+1);
		if(i==1)printf("X ");
		if(i==2)printf("= ");
	}
	scanf("%d",&ans);
	//judge if the student is right
	if(ans==temp[1]*temp[2])
	{
		flag=true;
		printf("Very good!\n");
		exercise_1();
	}
	else
	{
		flag=false;

		//if wrong, recycle until the student gets it right
		while(1)
		{
			if(wrong_multiplication(temp[1],temp[2],flag,1))
				{printf("Very good!\n");break;}
			else
				continue;
		}
		exercise_1();
	}
}