/*
	Program: Task_5_edition4
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-2
	Description: implementing CAI Project edition 4
*/
#include<stdio.h>
#include<stdbool.h>
#include<time.h>
#include<stdlib.h>

void randomResponse(bool flag);
bool wrong_multiplication(int a,int b,bool flag,int choice);
int level(int difficulty);
void judge_4(int num,int correct_num, int incorrect_num, int difficulty);
void exercise_4(int num,int correct_num, int incorrect_num,int difficulty);

int main()
{
	char start;
	int difficulty;
	printf("Please press enter to start: ");
	while(scanf("%c",&start) && start=='\n')
	{
		printf("Please input difficulty level: ");//input prompt
		scanf("%d",&difficulty);
		exercise_4(0,0,0,difficulty);
	}
	return 0;
}

void randomResponse(bool flag)
{
	int temp,seed=time(NULL);
	srand((unsigned int)seed);
	temp=rand()%4+1;
	if(flag)
	{	
		switch(temp)
		{
			case 1:printf("Very good!\n");break;
			case 2:printf("Excellent!\n");break;
			case 3:printf("Nice work!\n");break;
			case 4:printf("Keep up the good work!\n");break;
		}
	}
	else
	{
		switch(temp)
		{
			case 1:printf("No. Please try again!");break;
			case 2:printf("Wrong. Try once more");break;
			case 3:printf("Don't give up");break;
			case 4:printf("No. Keep trying");break;
		}
	}
}

bool wrong_multiplication(int a,int b,bool flag,int choice)
{
	int ans;
	randomResponse(flag);
	scanf("%d",&ans);
	if(ans==a*b)return true;
	else
		return false;
}
//calculate digit
int level(int difficulty)
{
	int n=1;
	for(int i=1;i<=difficulty;i++)
	{
		n*=10;
	}
	return n;
}

void judge_4(int num,int correct_num, int incorrect_num, int difficulty)
{
	float percent;
	printf("\n%d %d %d\n",num,correct_num,incorrect_num);
	percent = correct_num*1.0 / num;
	printf("%f\n",percent);
	if(percent<0.75)
	{
		printf("Please ask your teacher for extra help.\n");
		exercise_4(0,0,0,difficulty);
	}
	else
	{
		printf("Congratulations, you are ready to go to the next level!\n");
		exercise_4(0,0,0,difficulty);
	}
}

void exercise_4(int num,int correct_num, int incorrect_num,int difficulty)
{
	if(num==10)
	{
		judge_4(num, correct_num, incorrect_num, difficulty);
	}
	bool flag;
	int temp[3],ans,seed=time(NULL),digit;
	digit=level(difficulty);
	srand((unsigned int) seed);
	if(difficulty==1)
	{
		for(int i=1;i<=2;i++)
		{
			printf("%d ",temp[i]=rand()%9+1);
			if(i==1)printf("X ");
			if(i==2)printf("= ");
		}
	}
	else
	{
		for(int i=1;i<=2;i++)
		{
			printf("%d ",temp[i]=rand()%(digit-digit/10)+digit/10);
			if(i==1)printf("X ");
			if(i==2)printf("= ");
		}
	}
	scanf("%d",&ans);
	if(ans==temp[1]*temp[2])
	{
		flag=true;
		num++;
		correct_num++;
		randomResponse(flag);
		exercise_4(num,correct_num,incorrect_num,difficulty);
	}
	else
	{
		flag=false;
		num++;
		incorrect_num++;
		while(1)
		{
			if(num==10)
			{
				exercise_4(num,correct_num,incorrect_num,difficulty);
			}
			if(wrong_multiplication(temp[1],temp[2],flag,2))
			{
				num++;
				correct_num++;
				exercise_4(num,correct_num,incorrect_num,difficulty);
				break;
			}
			else
			{
				num++;
				incorrect_num++;
				continue;
			}
		}
	}
}