/*
	Program: Task_1
	Name: 李雪奇
	StudentNumber: 20301110
	Copyright: 2020
	Date: 2020-11-1
	Description: calculating two positive integers' GCD(Greatest Common Divisor)
*/
#include<stdio.h>

int getGCD(int x, int y)
{
	int maxx,minn,temp;
	//judging which is bigger
	if(x>y)
	{
		maxx=x;
		minn=y;
	}
	else
	{
		maxx=y;
		minn=x;
	}

	if(maxx%minn==0)return minn;
	temp = maxx % minn;
	getGCD(minn, temp);
}

int main()
{
	int a,b;
	printf("Please input two positive integers: ");//input prompt
	scanf("%d%d", &a,&b);
	printf("%d\n", getGCD(a,b));
	return 0;
}